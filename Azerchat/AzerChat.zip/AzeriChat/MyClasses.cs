﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzeriChat
{
    public  class MyClasses
    {

        public List<Message> messages { get; set; }
        public MyClasses()
        {

            messages = new()
            {

                new()
                {
                   // datetime = new DateTime(2012,05,6),
                   text = "salam necesen ne var ne yox",
                   title = "salamlasma",
                   description ="salamlaar"
                },
                  new()
                {
                   // datetime = new DateTime(2012,05,6),
                   text = "salam necesen ne var ne yox",
                   title = "salamlasma",
                   description ="salamlaar"
                },
                    new()
                {
                   // datetime = new DateTime(2012,05,6),
                   text = "salam necesen ne var ne yox",
                   title = "salamlasma",
                   description ="salamlaar"
                },
            };
            
        
        }

    }
}
