﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzeriChat
{
    public class Message
    {

        public Guid Id { get; set; }    
        public  string? datetime { get; set; }
        public string? text { get; set; }
        public string? title { get; set; }

        public string? description { get; set; }


        public override string ToString() =>
         $@"{datetime}--{text}--{title}--{description}";
        
    }
}
